export const REGISTRY_SAVE = '[RUN] [Registries] Save';
export const REGISTRIES_LOAD = '[RUN] [Registries] load';
export const LOAD_FTIME_DATA = '[RUN] [First Time] load';