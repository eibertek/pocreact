import Dashboard from './Dashboard.container';
import reducer from './reducers/Dashboard.reducer';
export const Reducer = reducer;

export default Dashboard;