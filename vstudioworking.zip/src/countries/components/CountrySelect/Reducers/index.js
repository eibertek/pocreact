import countries from './countries';
import currencies from './currencies';

export default {
  countries,
  currencies,
}