import Settings from './components/Settings.container';

export default Settings;