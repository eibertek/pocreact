
export const setFirstTimeData = ({ country, currency, dolar}) => ({
  type:'SET_FIRST_TIME_COUNTRY',
  country, currency, dolar
});

export default {
  setFirstTimeData,
};