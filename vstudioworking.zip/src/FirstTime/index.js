import FirstTime from './FirstTime.container.js';

export default FirstTime;