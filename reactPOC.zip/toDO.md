De Servicios crear:

Un endpoint que traiga Datos de cuestionario:

Campo TipoDeCampo Options Required Styles Etc

Despues hacer un fakeLogin, y segun los datos del usuario traer un formulario x

El formulario debe Aparecer por Ejemplo:

User / Asignee Mariano
Engagement EY.com
MigrationData 
    Country
    DateFrom
    DateTo
Questionnary
    QuestionnaryId
    Completed


Questionnary
  Id
  Fields

Field
  Id
  Name
  Type
  Options
  isRequired
  isEncrypted
  isCompleted
  CssStyles

ExampleQuestionnary
  Name      Input
  LastName  Input
  Sex       SexDropdown
  BirthDate DateInput
  DateFrom  DateInput
  DateTo    DateInput
  SafeQuestion1 QuestionDropdown
  SafeQuestion2 QuestionDropdown
  SafeQuestion3 QuestionDropdown
  CreditCard  CreditCardGroup



