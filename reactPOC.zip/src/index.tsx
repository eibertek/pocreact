import * as React from "react";
import * as ReactDOM from "react-dom";
import 'bootstrap';
import './styles.scss';

import { Hello, Input } from "./APP/Questionnaries/Components/Questionnary";

ReactDOM.render(
    <Hello compiler="TypeScript" framework="React" />,
    document.getElementById("example")
);