import * as React from "react";

export interface HelloProps { compiler: string; framework: string; }
export interface InputProps { type: string; 
                              name: string; 
                            }
export const Input = (props: InputProps) => 
    <input type={props.type} name={props.name} />;

export const Hello = (props: HelloProps) => 
  <React.Fragment>
    <h1>Hello from {props.compiler} and {props.framework}!</h1>
    <Input type="input" name="art" />
  </React.Fragment>;
