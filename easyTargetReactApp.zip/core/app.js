﻿import React from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';

class App extends React.Component {

    render() {
        return (
            <div>
                Hello, React! {this.props.nameMe}
           </div>
        )
    }
}

App.propTypes = {
    nameMe: PropTypes.String,
}

export default App;